<section id="main-content"  ng-init="jenis_lap = 'kabupaten';allData = <?php echo htmlspecialchars(json_encode($dataAll)); ?>"> 
    <section class="wrapper" id="wrap">
            <div class="row" >
                <div class="col-md-12" id="badan">
                    <h5 id="judul" style="top: -20px;">Daftar Laporan Kabupaten</h5>
                    <div style="text-align:right">
                        <label for="">Tahun</label>
                        <input  type="number" name="tahun" placeholder="tahun" ng-model="tahun" ng-change="cekTriwulan()">
                    </div>
                    <!-- <hr> -->
                    <!-- <br> -->
                    <table class="table table-bordered" >
                        <thead class="bg-primary">
                            <tr>
                                <th class="tengah" rowSpan="2" >No</th>
                                <th class="tengah" rowSpan="2">Laporan</th>
                                <th class="tengah" colspan="3">Tahun {{tahun}}</th>
                            </tr>
                            <tr>
                                <th class="tengah">Uraian</th>
                                <th class="tengah">Berkas</th>
                                <th class="tengah">Ket</th>
                            </tr>
                        </thead>
                        <tbody>
                        <tr>
                                <td class="tengah">
                                    1
                                </td>
                                <td>
                                    RPJMD
                                </td>
                                <td class="tengah">
                                    <img ng-if="getLapSKPD().ringkasan_renstra == undefined" src="<?php echo base_url() ?>../assets/img/silang.svg" alt="" style="width: 20px;">
                                    <img ng-if="getLapSKPD().ringkasan_renstra != undefined" src="<?php echo base_url() ?>../assets/img/ok2.png" alt="" style="width: 20px;">
                                </td>
                                <td class="tengah">
                                    <img ng-if="getLapSKPD().doc_renstra == undefined" src="<?php echo base_url() ?>../assets/img/silang.svg" alt="" style="width: 20px;">
                                    <img ng-if="getLapSKPD().doc_renstra != undefined" src="<?php echo base_url() ?>../assets/img/ok2.png" alt="" style="width: 20px;">
                                </td>
                                <td class="tengah">
                                    <button class="btn btn-primary btn-xs" ng-click="berkasOpen(getLapSKPD().doc_renstra)">View</button>
                                </td>
                            </tr>
                            <tr>
                                <td class="tengah">
                                    2
                                </td>
                                <td>
                                    RKPD
                                </td>
                                <td class="tengah">
                                    <img ng-if="getLapSKPD().ringkasan_rkp == undefined" src="<?php echo base_url() ?>../assets/img/silang.svg" alt="" style="width: 20px;">
                                    <img ng-if="getLapSKPD().ringkasan_rkp != undefined" src="<?php echo base_url() ?>../assets/img/ok2.png" alt="" style="width: 20px;">
                                </td>
                                <td class="tengah">
                                    <img ng-if="getLapSKPD().doc_rkp == undefined" src="<?php echo base_url() ?>../assets/img/silang.svg" alt="" style="width: 20px;">
                                    <img ng-if="getLapSKPD().doc_rkp != undefined" src="<?php echo base_url() ?>../assets/img/ok2.png" alt="" style="width: 20px;">
                                </td>
                                <td class="tengah">
                                    <button class="btn btn-primary btn-xs" ng-click="berkasOpen(getLapSKPD().doc_rkp)">View</button>
                                </td>
                            </tr>
                            <tr>
                                <td class="tengah">
                                    3
                                </td>
                                <td>
                                    PK Bupati
                                </td>
                                <td class="tengah">
                                    <img ng-if="getLapSKPD().ringkasan_pk == undefined" src="<?php echo base_url() ?>../assets/img/silang.svg" alt="" style="width: 20px;">
                                    <img ng-if="getLapSKPD().ringkasan_pk != undefined" src="<?php echo base_url() ?>../assets/img/ok2.png" alt="" style="width: 20px;">
                                </td>
                                <td class="tengah">
                                    <img ng-if="getLapSKPD().doc_pk == undefined" src="<?php echo base_url() ?>../assets/img/silang.svg" alt="" style="width: 20px;">
                                    <img ng-if="getLapSKPD().doc_pk != undefined" src="<?php echo base_url() ?>../assets/img/ok2.png" alt="" style="width: 20px;">
                                </td>
                                <td class="tengah">
                                    <button class="btn btn-primary btn-xs" ng-click="berkasOpen(getLapSKPD().doc_pk)">View</button>
                                </td>
                            </tr>
                            <tr>
                                <td class="tengah">
                                    4
                                </td>
                                <td>
                                    LKJIP
                                </td>
                                <td class="tengah">
                                    <img ng-if="getLapSKPD().ringkasan_lkjip == undefined" src="<?php echo base_url() ?>../assets/img/silang.svg" alt="" style="width: 20px;">
                                    <img ng-if="getLapSKPD().ringkasan_lkjip != undefined" src="<?php echo base_url() ?>../assets/img/ok2.png" alt="" style="width: 20px;">
                                </td>
                                <td class="tengah">
                                    <img ng-if="getLapSKPD().doc_lkjip == undefined" src="<?php echo base_url() ?>../assets/img/silang.svg" alt="" style="width: 20px;">
                                    <img ng-if="getLapSKPD().doc_lkjip != undefined" src="<?php echo base_url() ?>../assets/img/ok2.png" alt="" style="width: 20px;">
                                </td>
                                <td class="tengah">
                                    <button class="btn btn-primary btn-xs" ng-click="berkasOpen(getLapSKPD().doc_lkjip)">View</button>
                                </td>
                            </tr>
                            <tr>
                                <td class="tengah">
                                    5
                                </td>
                                <td>
                                    Rencana Aksi
                                </td>
                                <td class="tengah">
                                    <img ng-if="getLapSKPD().ringkasan_ra == undefined" src="<?php echo base_url() ?>../assets/img/silang.svg" alt="" style="width: 20px;">
                                    <img ng-if="getLapSKPD().ringkasan_ra != undefined" src="<?php echo base_url() ?>../assets/img/ok2.png" alt="" style="width: 20px;">
                                </td>
                                <td class="tengah">
                                    <img ng-if="getLapSKPD().doc_ra == undefined" src="<?php echo base_url() ?>../assets/img/silang.svg" alt="" style="width: 20px;">
                                    <img ng-if="getLapSKPD().doc_ra != undefined" src="<?php echo base_url() ?>../assets/img/ok2.png" alt="" style="width: 20px;">
                                </td>
                                <td class="tengah">
                                    <button class="btn btn-primary btn-xs" ng-click="berkasOpen(getLapSKPD().doc_ra)">View</button>
                                </td>
                            </tr>
                            <tr>
                                <td class="tengah">
                                    6
                                </td>
                                <td>
                                    IKU Kabupaten
                                </td>
                                <td class="tengah">
                                    <img ng-if="getLapSKPD().ringkasan_iku == undefined" src="<?php echo base_url() ?>../assets/img/silang.svg" alt="" style="width: 20px;">
                                    <img ng-if="getLapSKPD().ringkasan_iku != undefined" src="<?php echo base_url() ?>../assets/img/ok2.png" alt="" style="width: 20px;">
                                </td>
                                <td class="tengah">
                                    <img ng-if="getLapSKPD().doc_iku == undefined" src="<?php echo base_url() ?>../assets/img/silang.svg" alt="" style="width: 20px;">
                                    <img ng-if="getLapSKPD().doc_iku != undefined" src="<?php echo base_url() ?>../assets/img/ok2.png" alt="" style="width: 20px;">
                                </td>
                                <td class="tengah">
                                    <button class="btn btn-primary btn-xs" ng-click="berkasOpen(getLapSKPD().doc_iku)">View</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <!-- dialogbox -->
                    <div ng-if="iframe" id="showFrame" style="background:#2f323a; height:auto; top:0px;"  >
                        <div id="judulFrame">Dokumen
                            <a href="#" ng-click="iframeOpen()" style="float:right;margin-right:5px">&times;</a>
                        </div>
                            <iframe ng-src="{{urlBerkas(lapDoc)}}" frameborder="0"style="width: 99%;margin-top: 20px;min-height: 340px;" ></iframe>
                            <div style="text-align:center">
                                <span class="btn btn-info btn-xs" ng-click="iframeOpen()">Close</span>  
                            </div>
                    </div>
                    <!-- batas box -->
                </div>
            </div>
       
    </section>
</section>